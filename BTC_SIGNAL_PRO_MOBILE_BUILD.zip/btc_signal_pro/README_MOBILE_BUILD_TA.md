# BTC SIGNAL PRO – மொபைல் மூலம் APK Build

இந்த ZIP ஒரு Android Studio Kotlin/Compose source project. இது இன்னும் compile செய்யப்பட்டோ சாதனத்தில் சோதிக்கப்பட்டோ இல்லை.

## மொபைலில் இருந்து cloud build செய்வது
1. ZIP-ஐ extract செய்யவும்.
2. GitHub-ல் புதிய repository உருவாக்கவும்.
3. Extract செய்த project-இன் உள்ளடக்கங்களை repository-க்கு upload செய்து `main` branch-ல் commit செய்யவும்.
4. Repository-ல் **Actions** tab திறக்கவும்.
5. **Build BTC SIGNAL PRO APK** workflow தேர்வு செய்து **Run workflow** அழுத்தவும்.
6. Build வெற்றியடைந்தால் workflow run-ன் கீழே **Artifacts** பகுதியில் `BTC-SIGNAL-PRO-debug-apk` download செய்யவும்.
7. ZIP artifact-ஐ extract செய்து `app-debug.apk`-ஐ POCO M2 Pro-வில் install செய்யவும். Android கேட்டால் அந்த app-க்கு மட்டும் “Install unknown apps” அனுமதி கொடுக்கவும்.

## முக்கிய வரம்புகள்
- இது debug APK மட்டுமே; Play Store release/signing அல்ல.
- Live API இணைப்பு, indicator logic, alert நடத்தை ஆகியவை உண்மையான மொபைலில் சரிபார்க்கப்பட வேண்டும்.
- App திறந்திருக்கும் போது polling செய்கிறது; background-ல் அல்லது app மூடப்பட்டபோது alert உறுதி இல்லை.
- Supertrend இன்னும் code-ல் implement செய்யப்படவில்லை; VWAP ஒரு rolling 20-candle approximation.
- இது financial advice அல்ல. முதலில் paper/demo-வில் சோதிக்கவும்; signals லாபத்தை உறுதி செய்யாது.
