# BTC SIGNAL PRO (Android starter project)

A Kotlin + Jetpack Compose Android starter for Delta Exchange India BTCUSD public market data.

## Included
- Delta India public ticker and historical OHLC REST requests (5m and 15m)
- Basic EMA9/EMA21 + rolling VWAP + price confirmation rule
- 15m trend / 5m confirmation display
- Indicative ATR-based SL and two targets
- Sound, vibration, and notification alert hooks
- No API keys and no order-placement code

## Important limitations
This is an uncompiled starter prototype, not a verified trading product or APK. It polls while the app is open; it does not yet run a persistent background service, so alerts are not guaranteed when Android suspends/closes the app. The first-pass signal engine is intentionally conservative/simple: the Supertrend indicator is listed in the UI plan but is not yet implemented in this prototype, and VWAP uses the most recent 20 candles rather than a full exchange-session VWAP. It must be backtested and paper-traded before use. Signals are not financial advice and can lose money.

## Build
Open this folder in Android Studio (recent version), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). Android SDK 35 is configured. On Android 13+, allow notification permission.

Delta API base: https://api.india.delta.exchange
Docs: https://docs.delta.exchange/
